# 🦕 DINO RUSH — Godot 4 Project

## HOW TO OPEN

1. **Godot 4.2+** download karo: https://godotengine.org/download
2. Godot open karo → "Import" click karo
3. Is folder ke andar `project.godot` file select karo
4. "Import & Edit" press karo
5. Play button dabao (F5) ✅

## CONTROLS

| Action | Key |
|--------|-----|
| Jump   | SPACE / UP Arrow / Screen Tap |
| Double Jump | Phir se SPACE / UP |
| Duck   | DOWN Arrow |

## FEATURES

- 🦕 Custom Blue Dino sprite
- 🌙 NIGHT — Mountains + Stars + Moon
- ☀️ DAY — Pyramids + Sun + Blue sky
- 🌅 EVENING — Taj Mahal + Orange sunset
- Smooth environment crossfade transitions
- Cactus + Pterodactyl obstacles
- Gold coins collect karo (+100 score)
- 3 lives system
- Double jump with gold glow
- Sound effects (Web build mein)

## PROJECT STRUCTURE

```
dino_godot/
├── project.godot       ← Main project file
├── assets/
│   └── dino.png        ← Dino sprite
├── scenes/
│   └── Main.tscn       ← Main scene
└── scripts/
    ├── Main.gd         ← Game logic
    └── Dino.gd         ← Dino physics
```

## EXPORT (Android APK)

1. Godot mein: Project → Export
2. "Android" add karo
3. Debug APK export karo

---
Made with ❤️ using Godot 4
